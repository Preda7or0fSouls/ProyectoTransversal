package modelo;

public class Equipo {

}
