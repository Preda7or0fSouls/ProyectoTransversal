package modelo;

public class Jugador {

}
