package modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class DataConnection {
	private String usuario;
	private String password;

	private Connection conn;

	public DataConnection(String usuario, String password) {
		super();
		this.usuario = usuario;
		this.password = password;
	}

	// Metodo que se conecta a la base de datos
	// y devuelve un objeto de conexion a la misma
	public Connection getConn() throws ClassNotFoundException {
		String urlConnection;
		Properties infoConnection;

		urlConnection = "jdbc:mysql://localhost:3306/nba";
		infoConnection = new Properties();
		infoConnection.put("user", this.usuario);
		infoConnection.put("password", this.password);

		try {
			// Registrar el driver de conexion a la base de datos
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection(urlConnection, infoConnection);
			System.out.println("Conexion establecida");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.getMessage();
		}

		return conn;
	}

	// Metodo que recupera todos los registros de la tabla
	// departamentos
	public ResultSet dameEquipos() {
		ResultSet rs = null;
		// El siguiente objeto contendra la consulta a lanzar
		// ligada a la conexion a la base de datos o esquema.
		Statement stmt = null;
		String query = "SELECT * FROM nba.equipos;";

		// Hay que conectarse a la base de datos
		// para a treves de la conexion obtenmida lanzar las consultas
		try {
			conn = getConn();
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return rs;
	}
	
	// Metodo que recupera todos los registros de la tabla
		// departamentos
		public ResultSet dameJugadores() {
			ResultSet rs = null;
			// El siguiente objeto contendra la consulta a lanzar
			// ligada a la conexion a la base de datos o esquema.
			Statement stmt = null;
			String query = "SELECT * FROM empresa.jugadores;";

			// Hay que conectarse a la base de datos
			// para a treves de la conexion obtenmida lanzar las consultas
			try {
				conn = getConn();
				stmt = conn.createStatement();
				rs = stmt.executeQuery(query);
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return rs;
		}
		
		//Este metodo contiene una consulta preparada para evitar inyecciones SQL
		// Metodo que devuelve los jugadores de un equipo
		public ResultSet jugadoresEquipo(int idEquipo) throws SQLException, ClassNotFoundException {
			ResultSet rs = null;
			
			// El siguiente objeto contendra la consulta a lanzar
			// ligada a la conexion a la base de datos o esquema.
			String query = "SELECT * FROM nba.jugadores"
						+ " WHERE idEquipo = ?";
			
			// Siempre que una consulta tenga parametros, hay que utilizar sentencias
			// preparadas
			PreparedStatement stmt;
			try {
				conn = getConn();
				stmt = conn.prepareStatement(query);
				stmt.setInt(1, idEquipo);
				rs = stmt.executeQuery();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return rs;
		}
}
