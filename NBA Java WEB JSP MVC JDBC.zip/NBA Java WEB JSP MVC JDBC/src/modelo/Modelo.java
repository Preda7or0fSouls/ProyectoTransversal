package modelo;

public class Modelo {
	// Aqui definimos las listas de equipos y jugadores
	// List<Equipo> equipos;
	// List<Jugador> jugadores;
	
	// Creamos el contructor
	public Modelo() {
		// TODO Auto-generated constructor stub
	}
	// Creamos los getters y setters
	// En los getters hacemos la consulta a la BBDD
	// y rellenamos las listas
	
}
